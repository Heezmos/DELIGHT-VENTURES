from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import os
import json
import httpx
import jwt
import bcrypt
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

app = FastAPI(title="Delight Ventures Limited — Backend API")

# ── CORS: allow your frontend domain ─────────────────────────────────────────
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ════════════════════════════════════════════════════════════════════════════
# DATABASE — SQLite (file-based, zero setup, persists on Railway/Render volume)
# ════════════════════════════════════════════════════════════════════════════

DB_PATH = Path(os.getenv("DB_PATH", "dvaec.db"))

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            name TEXT DEFAULT 'Executive',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT NOT NULL,
            question TEXT NOT NULL,
            report_json TEXT NOT NULL,
            result TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()

    # Seed default CEO account on first run, from env vars, if no users exist yet
    existing = conn.execute("SELECT COUNT(*) as c FROM users").fetchone()["c"]
    if existing == 0:
        seed_email = os.getenv("CEO_EMAIL")
        seed_pass  = os.getenv("CEO_PASSWORD")
        seed_name  = os.getenv("CEO_NAME", "Executive")
        if seed_email and seed_pass:
            hashed = bcrypt.hashpw(seed_pass.encode(), bcrypt.gensalt()).decode()
            conn.execute(
                "INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)",
                (seed_email.lower().strip(), hashed, seed_name)
            )
            conn.commit()
    conn.close()

init_db()

# ════════════════════════════════════════════════════════════════════════════
# AUTHENTICATION — JWT-based, credentials never live in frontend code
# ════════════════════════════════════════════════════════════════════════════

JWT_SECRET    = os.getenv("JWT_SECRET", "change-this-secret-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 12


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


def create_token(email: str) -> str:
    payload = {
        "sub": email,
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRY_HOURS),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def verify_token(authorization: str = Header(None)) -> str:
    """Dependency that protects routes — extracts and validates the Bearer token."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authorization header.")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Session expired. Please log in again.")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid session token.")


@app.post("/auth/login")
def login(payload: LoginRequest):
    conn = get_db()
    user = conn.execute(
        "SELECT * FROM users WHERE email = ?", (payload.email.lower().strip(),)
    ).fetchone()
    conn.close()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password.")

    if not bcrypt.checkpw(payload.password.encode(), user["password_hash"].encode()):
        raise HTTPException(status_code=401, detail="Invalid email or password.")

    token = create_token(user["email"])
    return {
        "success": True,
        "token": token,
        "user": {"email": user["email"], "name": user["name"]},
    }


@app.get("/auth/me")
def me(current_user: str = Depends(verify_token)):
    conn = get_db()
    user = conn.execute("SELECT email, name FROM users WHERE email = ?", (current_user,)).fetchone()
    conn.close()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    return {"email": user["email"], "name": user["name"]}


# ════════════════════════════════════════════════════════════════════════════
# CONTACT FORM
# ════════════════════════════════════════════════════════════════════════════

class ContactForm(BaseModel):
    name: str
    email: EmailStr
    service: str = "General Inquiry"
    message: str


SMTP_HOST     = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT     = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER     = os.getenv("SMTP_USER")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")
NOTIFY_TO     = os.getenv("NOTIFY_TO")


def build_email(form: ContactForm) -> MIMEMultipart:
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"New Inquiry: {form.service} — from {form.name}"
    msg["From"]    = SMTP_USER
    msg["To"]      = NOTIFY_TO
    msg["Reply-To"] = form.email

    timestamp = datetime.now().strftime("%d %B %Y, %H:%M")

    html_body = f"""
    <!DOCTYPE html><html><head><meta charset="UTF-8"/>
    <style>
      body {{ font-family: Georgia, serif; background:#F7F0E4; margin:0; padding:0; }}
      .wrapper {{ max-width:600px; margin:40px auto; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 4px 24px rgba(0,0,0,0.1); }}
      .header {{ background:#26190E; padding:32px 40px; text-align:center; }}
      .header h1 {{ color:#C0904F; font-size:22px; margin:0; letter-spacing:1px; }}
      .header p  {{ color:rgba(255,255,255,0.5); font-size:12px; margin:6px 0 0; }}
      .body {{ padding:36px 40px; }}
      .field {{ margin-bottom:24px; border-bottom:1px solid #F0E8D8; padding-bottom:20px; }}
      .field:last-child {{ border-bottom:none; margin-bottom:0; }}
      .label {{ font-size:10px; letter-spacing:2px; text-transform:uppercase; color:#C0904F; font-weight:700; margin-bottom:6px; }}
      .value {{ font-size:15px; color:#26190E; line-height:1.6; }}
      .message-box {{ background:#F7F0E4; border-left:3px solid #C0904F; padding:16px 20px; border-radius:0 8px 8px 0; }}
      .footer {{ background:#F7F0E4; padding:20px 40px; text-align:center; font-size:11px; color:#7A6550; }}
    </style></head>
    <body>
      <div class="wrapper">
        <div class="header"><h1>Delight Ventures Limited</h1><p>New Contact Form Submission · {timestamp}</p></div>
        <div class="body">
          <div class="field"><div class="label">Full Name</div><div class="value">{form.name}</div></div>
          <div class="field"><div class="label">Email Address</div><div class="value"><a href="mailto:{form.email}" style="color:#C0904F;">{form.email}</a></div></div>
          <div class="field"><div class="label">Service of Interest</div><div class="value">{form.service}</div></div>
          <div class="field"><div class="label">Message</div><div class="value"><div class="message-box">{form.message}</div></div></div>
        </div>
        <div class="footer">Reply directly to this email to respond to {form.name}.<br/>Delight Ventures Limited — Freetown, Sierra Leone</div>
      </div>
    </body></html>
    """

    plain_body = (
        f"New inquiry from Delight Ventures Limited website\n"
        f"Received: {timestamp}\n\nName: {form.name}\nEmail: {form.email}\nService: {form.service}\n\nMessage:\n{form.message}\n"
    )

    msg.attach(MIMEText(plain_body, "plain"))
    msg.attach(MIMEText(html_body, "html"))
    return msg


def build_autoreply(form: ContactForm) -> MIMEMultipart:
    msg = MIMEMultipart("alternative")
    msg["Subject"] = "We received your message — Delight Ventures Limited"
    msg["From"]    = SMTP_USER
    msg["To"]      = form.email

    html_body = f"""
    <!DOCTYPE html><html><head><meta charset="UTF-8"/>
    <style>
      body {{ font-family: Georgia, serif; background:#F7F0E4; margin:0; padding:0; }}
      .wrapper {{ max-width:600px; margin:40px auto; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 4px 24px rgba(0,0,0,0.1); }}
      .header {{ background:#26190E; padding:40px; text-align:center; }}
      .header h1 {{ color:#C0904F; font-size:24px; margin:0 0 8px; }}
      .header p  {{ color:rgba(255,255,255,0.55); font-size:13px; margin:0; }}
      .body {{ padding:40px; color:#26190E; line-height:1.8; font-size:15px; }}
      .body h2 {{ color:#C0904F; font-size:18px; margin-bottom:12px; }}
      .highlight {{ background:#F7F0E4; border-left:3px solid #C0904F; padding:16px 20px; border-radius:0 8px 8px 0; margin:24px 0; font-size:14px; color:#7A6550; }}
      .footer {{ background:#F7F0E4; padding:24px 40px; text-align:center; font-size:11px; color:#7A6550; border-top:1px solid #EDE0CC; }}
    </style></head>
    <body>
      <div class="wrapper">
        <div class="header"><h1>Delight Ventures Limited</h1><p>Helping businesses scale digitally — Freetown, Sierra Leone</p></div>
        <div class="body">
          <h2>Dear {form.name},</h2>
          <p>Thank you for reaching out to us. We have received your inquiry regarding <strong>{form.service}</strong> and our team will get back to you shortly.</p>
          <div class="highlight">We typically respond within <strong>1–2 business days</strong>. For urgent matters, please call us directly on <strong>+23231556611</strong> or <strong>+23279674048</strong>.</div>
          <p>We look forward to working with you and helping your business grow.</p>
          <p style="margin-top:32px;">Warm regards,<br/><strong style="color:#C0904F;">The Delight Ventures Team</strong></p>
        </div>
        <div class="footer">Delight Ventures Limited · Freetown, Sierra Leone<br/>+23231556611 / +23279674048 · info@delightventures.com</div>
      </div>
    </body></html>
    """

    plain = (
        f"Dear {form.name},\n\nThank you for contacting Delight Ventures Limited.\n"
        f"We've received your inquiry about {form.service} and will respond within 1-2 business days.\n\n"
        f"For urgent matters: +23231556611 / +23279674048\n\nWarm regards,\nDelight Ventures Limited"
    )

    msg.attach(MIMEText(plain, "plain"))
    msg.attach(MIMEText(html_body, "html"))
    return msg


@app.get("/")
def root():
    return {"status": "Delight Ventures Limited API is running"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/contact")
def contact(form: ContactForm):
    if not form.name.strip():
        raise HTTPException(status_code=422, detail="Name is required.")
    if not form.message.strip():
        raise HTTPException(status_code=422, detail="Message is required.")
    if len(form.message.strip()) < 10:
        raise HTTPException(status_code=422, detail="Message is too short.")

    if not all([SMTP_USER, SMTP_PASSWORD, NOTIFY_TO]):
        raise HTTPException(status_code=500, detail="Email server not configured.")

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_USER, NOTIFY_TO, build_email(form).as_string())
            server.sendmail(SMTP_USER, form.email, build_autoreply(form).as_string())
    except smtplib.SMTPAuthenticationError:
        raise HTTPException(status_code=500, detail="Email authentication failed.")
    except smtplib.SMTPException as e:
        raise HTTPException(status_code=500, detail=f"Email sending failed: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

    return {"success": True, "message": "Your message has been sent."}


# ════════════════════════════════════════════════════════════════════════════
# DV-AEC — AI EXECUTIVE COUNCIL
# ════════════════════════════════════════════════════════════════════════════

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL    = "claude-sonnet-4-6"

DVL_KNOWLEDGE_BASE = """
Delight Ventures Limited (DVL) is a business solutions company headquartered in Freetown, Sierra Leone.
Mission: Empower businesses with professional registration, digital transformation, and creative branding solutions that support growth, visibility, and long-term success.
Vision: Become a leading business and digital solutions company in Sierra Leone and across Africa by helping businesses build strong operational and digital foundations.
Core Services:
1. Business Registration & Compliance — business registration, tax registration, NASSIT setup, licenses, business consultancy.
2. Website, Ecommerce & Business Systems — corporate websites, ecommerce platforms, ERP/CRM/HRM systems, payment gateway & inventory integration, mobile apps, WhatsApp-integrated platforms.
3. Photography & Videography — corporate shoots, event coverage, product shoots, promotional content, commercial & branding visuals.
CEO: Henrison Moseray.
Target market: Startups, SMEs, hotels & hospitality, retail businesses, corporate organizations, NGOs & institutions, entrepreneurs and personal brands.
Core Values: Integrity, Innovation, Sustainability, Excellence, Collaboration.
""".strip()

CHAIRMAN_SYSTEM_PROMPT = f"""You are the Chairman AI of the Delight Ventures AI Executive Council (DV-AEC). You coordinate a virtual board of 7 AI executive directors to help CEO Henrison Moseray make business decisions. The CEO remains the final decision-maker — you only provide structured analysis and recommendations.

Company knowledge base:
{DVL_KNOWLEDGE_BASE}

The 7 directors and their focus areas:
1. Strategy & Growth Director — business growth, expansion opportunities, long-term planning, competitive advantage.
2. Finance & Investment Director — financial planning, pricing, profitability, investment readiness.
3. Technology & Innovation Director — software solutions, AI adoption, digital transformation, technology strategy.
4. Business Intelligence Director — data analysis, market trends, performance measurement, decision support.
5. Marketing & Brand Director — customer acquisition, branding, marketing campaigns, market positioning.
6. Operations Director — internal systems, service delivery, efficiency, scalability.
7. Social Impact Director — community impact, sustainability, ethical business practices.

When given a CEO question, produce a full board meeting report. Respond ONLY with valid JSON, no markdown fences, no preamble, in exactly this structure:
{{
  "resolution": "2-3 sentence board resolution summarising the collective decision",
  "result": "Approved" or "Conditional Approval" or "Rejected",
  "votes": {{
    "strategy": "Approve" or "Conditional" or "Reject",
    "finance": "Approve" or "Conditional" or "Reject",
    "tech": "Approve" or "Conditional" or "Reject",
    "bi": "Approve" or "Conditional" or "Reject",
    "marketing": "Approve" or "Conditional" or "Reject",
    "ops": "Approve" or "Conditional" or "Reject",
    "impact": "Approve" or "Conditional" or "Reject"
  }},
  "responses": {{
    "strategy": "2-3 sentence analysis from Strategy & Growth Director",
    "finance": "2-3 sentence analysis from Finance & Investment Director",
    "tech": "2-3 sentence analysis from Technology & Innovation Director",
    "bi": "2-3 sentence analysis from Business Intelligence Director",
    "marketing": "2-3 sentence analysis from Marketing & Brand Director",
    "ops": "2-3 sentence analysis from Operations Director",
    "impact": "2-3 sentence analysis from Social Impact Director"
  }},
  "actions": ["Action item 1", "Action item 2", "Action item 3", "Action item 4", "Action item 5"]
}}"""


class CouncilQuestion(BaseModel):
    question: str


@app.post("/council/convene")
async def convene_council(payload: CouncilQuestion, current_user: str = Depends(verify_token)):
    question = payload.question.strip()
    if not question:
        raise HTTPException(status_code=422, detail="A question is required.")
    if not ANTHROPIC_API_KEY:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY not configured on server.")

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": ANTHROPIC_MODEL,
                    "max_tokens": 1500,
                    "system": CHAIRMAN_SYSTEM_PROMPT,
                    "messages": [{"role": "user", "content": f"CEO Question: {question}"}],
                },
            )

        if response.status_code != 200:
            raise HTTPException(status_code=502, detail=f"AI provider error: {response.text[:200]}")

        data = response.json()
        raw_text = data.get("content", [{}])[0].get("text", "")
        raw_text = raw_text.strip()
        if raw_text.startswith("```"):
            raw_text = raw_text.split("```")[1]
            if raw_text.startswith("json"):
                raw_text = raw_text[4:]
        report = json.loads(raw_text.strip())

    except json.JSONDecodeError:
        raise HTTPException(status_code=502, detail="The Chairman AI returned an unparseable response. Please try again.")
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="The board session timed out. Please try again.")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

    return report


# ════════════════════════════════════════════════════════════════════════════
# DECISION ARCHIVE — persisted server-side, survives across devices/browsers
# ════════════════════════════════════════════════════════════════════════════

class ArchiveEntry(BaseModel):
    question: str
    report: dict


@app.post("/council/archive")
def save_decision(entry: ArchiveEntry, current_user: str = Depends(verify_token)):
    conn = get_db()
    conn.execute(
        "INSERT INTO decisions (user_email, question, report_json, result) VALUES (?, ?, ?, ?)",
        (current_user, entry.question, json.dumps(entry.report), entry.report.get("result", ""))
    )
    conn.commit()
    conn.close()
    return {"success": True, "message": "Decision archived."}


@app.get("/council/archive")
def list_decisions(current_user: str = Depends(verify_token)):
    conn = get_db()
    rows = conn.execute(
        "SELECT id, question, report_json, result, created_at FROM decisions WHERE user_email = ? ORDER BY created_at DESC",
        (current_user,)
    ).fetchall()
    conn.close()
    return [
        {
            "id": row["id"],
            "question": row["question"],
            "report": json.loads(row["report_json"]),
            "result": row["result"],
            "timestamp": row["created_at"],
        }
        for row in rows
    ]


@app.delete("/council/archive/{decision_id}")
def delete_decision(decision_id: int, current_user: str = Depends(verify_token)):
    conn = get_db()
    conn.execute(
        "DELETE FROM decisions WHERE id = ? AND user_email = ?",
        (decision_id, current_user)
    )
    conn.commit()
    conn.close()
    return {"success": True}
